set -eu
export PATH=/opt/oap-prerequisites/python/bin:$PATH
export REPO=/opt/openappplatform-source J=/opt/openappplatform-source/tests/vps/release-journey BUNDLE=/opt/oap-journey-bundle BIN=/opt/oap-journey-bundle/bin DIR=/opt/oap-journey OUT=/opt/oap-journey-evidence BASE=nishashipping.com URL=http://127.0.0.1:8878
cd "$REPO"
python3 -I "$J/bundle.py" load --bundle "$BUNDLE" > "$OUT/A-load.log" 2>&1
. "$BUNDLE/journey.env"
# Authorized downtime, after the candidate bundle is verified.
(cd /opt/oap-standalone && docker compose stop)
python3 scripts/install.py init --json --directory "$DIR" --image "$OAP_IMAGE" --environment production --ingress-tls letsencrypt --ingress-bind 0.0.0.0 --ingress-domain "cli.$BASE" --ingress-domain "rest.$BASE" --ingress-domain "mcp.$BASE" > "$OUT/A-init.json"
python3 scripts/install.py start --json --directory "$DIR" > "$OUT/A-start.json"
python3 scripts/install.py check --json --directory "$DIR" > "$OUT/A-check.json"
install -d -m 700 "$DIR/creds"
date -u +%FT%TZ > "$OUT/A-finished-at.txt"

printf "A-end %s\n" "$(date -u +%FT%TZ)" >> "$OUT/timings.txt"
