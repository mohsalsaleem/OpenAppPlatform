set -eu
export PATH=/opt/oap-prerequisites/python/bin:$PATH
export REPO=/opt/openappplatform-source J=/opt/openappplatform-source/tests/vps/release-journey BUNDLE=/opt/oap-journey-bundle BIN=/opt/oap-journey-bundle/bin DIR=/opt/oap-journey OUT=/opt/oap-journey-evidence BASE=nishashipping.com URL=http://127.0.0.1:8878
cd "$REPO"
git fetch origin main
git checkout --detach 11d5b85
# Preserve all previous test directories. No existing install configuration is overwritten.
if test -e "$DIR"; then mv "$DIR" /opt/oap-journey-before-11d5b85; fi
if test -e "$OUT"; then mv "$OUT" /opt/oap-journey-evidence-before-11d5b85; fi
mkdir -m 700 "$OUT"
date -u +%FT%TZ > "$OUT/started-at.txt"
printf "A-start %s\n" "$(date -u +%FT%TZ)" >> "$OUT/timings.txt"
git rev-parse HEAD > "$OUT/A-checkout.txt"
{ uname -a; nproc; free -m; swapon --show; df -h /var/lib/docker /opt; python3 --version; docker version --format '{{.Server.Version}}'; } > "$OUT/A-preflight.txt" 2>&1
python3 - <<'BASELINE'
import subprocess,json,pathlib
r=subprocess.run(['journalctl','-k','--no-pager','-q','-o','short-iso'],capture_output=True,text=True)
lines=[l for l in r.stdout.splitlines() if 'Out of memory' in l or 'oom-kill' in l]
x={'historicalOomLogLines':len(lines),'logReadable':r.returncode==0,'lastEventAt':lines[-1].split()[0] if lines else None,'scope':'before this journey'}
pathlib.Path('/opt/oap-journey-evidence/A-historical-oom.json').write_text(json.dumps(x,indent=2)+'\n')
BASELINE
nohup python3 -I "$J/monitor.py" run --out "$OUT/monitor.jsonl" --duration 21600 > /dev/null 2>&1 < /dev/null &
echo $! > "$OUT/monitor.pid"
