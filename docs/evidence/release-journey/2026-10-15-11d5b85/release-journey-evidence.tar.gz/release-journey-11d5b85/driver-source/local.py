import importlib.util,json,os,shutil,subprocess
from pathlib import Path
r=Path.cwd();s=importlib.util.spec_from_file_location('h',r/'scripts/test-env.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
last=json.loads((r/'.local/test-env/runs/20261015-153237-538a4cb9/result.json').read_text());folder=r/'.local/journey-11d5b85/local';folder.mkdir(parents=True,exist_ok=True);source=folder/'source';source.mkdir(exist_ok=True)
for name in h.source_names():
 p=r/name
 if p.is_file():q=source/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
docker,env=h.docker_client();env.update(last['images']);project='oap-journey-local-11d5b85';old=last['project']
env.update(OAP_TEST_RUN_DIR=str(folder),OAP_TEST_RUNNER_IMAGE='openappplatform-test:'+last['fingerprint'][:16],OAP_TEST_PLATFORM_IMAGE='openappplatform-test-install:'+old,OAP_TEST_FIXTURE_V1='openappplatform-test-fixture:'+old+'-v1',OAP_TEST_FIXTURE_V2='openappplatform-test-fixture:'+old+'-v2',OAP_TEST_DATABASE_IMAGE='openappplatform-test-database:'+old,OAP_TEST_WORKER_IMAGE='openappplatform-test-worker:'+old,OAP_TEST_APPLICATION_IMAGE='openappplatform-test-application:'+old,OAP_TEST_CADDY_IMAGE='openappplatform-test-caddy:'+old)
archive=folder/'fixtures.tar'
if not archive.exists():os.link(r/'.local/test-env/runs/20261015-153237-538a4cb9/fixtures.tar',archive)
compose=docker+['compose','-f','tests/env/compose.yaml','-p',project]
subprocess.run(compose+['up','-d','--wait','postgres','docker'],env=env,check=True)
cmd=compose+['run','--rm','--no-deps','--entrypoint','python3','--volume',str(source)+':/opt/openappplatform-source:ro','--volume',str(r/'.local/journey-11d5b85/bundle')+':/opt/oap-journey-bundle','--volume',str(r/'.local/journey-11d5b85/local-setup.py')+':/opt/local-setup.py:ro','--volume',str(r/'.local/journey-11d5b85/local-runner.py')+':/opt/local-runner.py:ro','--workdir','/opt/openappplatform-source','runner','/opt/local-setup.py']
try:subprocess.run(cmd,env=env,check=True)
finally:subprocess.run(compose+['down','--volumes','--remove-orphans'],env=env)
