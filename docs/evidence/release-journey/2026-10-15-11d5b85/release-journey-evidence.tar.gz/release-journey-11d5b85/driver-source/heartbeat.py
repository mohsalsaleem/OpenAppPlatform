import json,subprocess,time,datetime,signal
from pathlib import Path
root=Path(__file__).resolve().parent
code="""import pathlib,json,datetime
p=pathlib.Path('/opt/oap-journey-evidence/monitor.jsonl')
rows=[json.loads(l) for l in p.read_text().splitlines()[-20:] if l.strip()]
low=[]
for row in reversed(rows):
 if row.get('memAvailableMiB',1000)>=100:break
 low.append(row)
span=0
if len(low)>1:span=(datetime.datetime.strptime(low[0]['t'],'%Y-%m-%dT%H:%M:%SZ')-datetime.datetime.strptime(low[-1]['t'],'%Y-%m-%dT%H:%M:%SZ')).total_seconds()
age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.strptime(rows[-1]['t'],'%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)).total_seconds() if rows else 999
print(json.dumps({'last':rows[-1] if rows else None,'lowMemorySeconds':span,'sampleAgeSeconds':age,'stop':span>60 or age>45}))
"""
import shlex
command='echo BEGIN_JOURNEY\n/opt/oap-prerequisites/python/bin/python3 -c '+shlex.quote(code)+'\necho END_JOURNEY\n'
(root/'heartbeat-ssh.sh').write_text(command)
finish=time.monotonic()+21600
with open(root/'evidence/ssh-health.jsonl','a',buffering=1) as out:
 while time.monotonic()<finish and not (root/'HEARTBEAT_DONE').exists():
  try:
   p=subprocess.run(['expect',str(root/'ssh.exp'),str(root/'heartbeat-ssh.sh')],capture_output=True,text=True,timeout=45)
   if p.returncode:raise RuntimeError('SSH did not answer with a receipt')
   x=json.loads(p.stdout);x['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();out.write(json.dumps(x)+'\n')
   if x.get('stop'):
    (root/'HOST_STOP.json').write_text(json.dumps({'reason':'memory_below_100_MiB_over_one_minute','evidence':x}));break
  except Exception as e:
   x={'reason':'ssh_or_monitor_unavailable','error':str(e),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};out.write(json.dumps(x)+'\n');(root/'HOST_STOP.json').write_text(json.dumps(x));break
  time.sleep(15)
