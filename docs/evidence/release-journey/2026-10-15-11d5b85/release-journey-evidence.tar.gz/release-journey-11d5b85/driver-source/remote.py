import json,subprocess,sys,shlex
from pathlib import Path
root=Path(__file__).resolve().parent
stage=sys.argv[1];body=Path(sys.argv[2]).read_text()
remote_dir='/opt/oap-journey-transport-11d5b85'
command='mkdir -p '+remote_dir+'\nsh -c '+shlex.quote(body)+' > '+remote_dir+'/'+stage+'.stdout 2> '+remote_dir+'/'+stage+'.stderr\nrc=$?\necho BEGIN_JOURNEY\n/opt/oap-prerequisites/python/bin/python3 -c '+shlex.quote("import json,pathlib,sys;print(json.dumps({'exitCode':int(sys.argv[1]),'stdout':pathlib.Path(sys.argv[2]).read_text(),'stderr':pathlib.Path(sys.argv[3]).read_text()}))")+' "$rc" '+remote_dir+'/'+stage+'.stdout '+remote_dir+'/'+stage+'.stderr\necho END_JOURNEY\n'
p=root/(stage+'-transport.sh');p.write_text(command)
r=subprocess.run(['expect',str(root/'ssh.exp'),str(p)],capture_output=True,text=True,timeout=790)
if r.returncode:print('SSH result uncertain; stop and preserve command');raise SystemExit(r.returncode)
x=json.loads(r.stdout);(root/(stage+'-transport.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x));raise SystemExit(x['exitCode'])
