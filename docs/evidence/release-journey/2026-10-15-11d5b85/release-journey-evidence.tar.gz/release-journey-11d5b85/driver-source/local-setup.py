import os,json,subprocess,secrets,sys,time
from pathlib import Path
os.environ['DOCKER_HOST']='unix:///run/oap-test/docker.sock';os.environ.pop('DOCKER_CONTEXT',None)
R=Path('/opt/openappplatform-source');os.chdir(R);D=Path('/report/installation');O=Path('/report/evidence');D.mkdir(mode=0o700,exist_ok=True);O.mkdir(exist_ok=True)
(O/'started-at.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
def call(c,body=None):
 p=subprocess.run(c,input=body,capture_output=True,text=True);print(c[0],c[1] if len(c)>1 else '',p.returncode,flush=True)
 if p.returncode:print(p.stdout,p.stderr);raise RuntimeError('Local setup command failed')
 return p.stdout
call(['docker','load','-i','/report/fixtures.tar'])
loaded=call(['python3','-I','tests/vps/release-journey/bundle.py','load','--bundle','/opt/oap-journey-bundle']);(O/'A-load.txt').write_text(loaded)
m=json.loads(Path('/opt/oap-journey-bundle/manifest.json').read_text());exports={'OAP_IMAGE':'openappplatform:rc','JOB':'oap-journey-job:v1','WEB':'oap-journey-api:web-v1','API1':'oap-journey-api:v1','API2':'oap-journey-api:v2','APIBAD':'oap-journey-api:broken','NOTES':'oap-journey-notes:v1','NOTES2':'oap-journey-notes:v2','WORKER':'oap-journey-worker:v1'};(O/'images.json').write_text(json.dumps({k:m['images'][v] for k,v in exports.items()}))
db=call(['docker','image','inspect','--format','{{.Id}}',os.environ['OAP_TEST_DATABASE_IMAGE']]).strip();caddy=call(['docker','image','inspect','--format','{{.Id}}',os.environ['OAP_TEST_CADDY_IMAGE']]).strip()
base=['python3','scripts/install.py'];args=['--json','--directory',str(D)]
try:
 out=call(base+['init']+args+['--image',m['images']['openappplatform:rc'],'--docker-socket','/run/oap-test/docker.sock','--postgres-image',db,'--ingress-image',caddy,'--environment','production','--port','8878','--ingress-tls','internal','--ingress-bind','127.0.0.1','--ingress-domain','cli.journey.test','--ingress-domain','rest.journey.test','--ingress-domain','mcp.journey.test']);(O/'A-init.json').write_text(out)
 (O/'A-start.json').write_text(call(base+['start']+args));(O/'A-check.json').write_text(call(base+['check']+args))
 (D/'creds').mkdir(mode=0o700,exist_ok=True)
 owner=json.dumps({'email':'journey-owner@example.invalid','name':'Journey test owner','password':secrets.token_urlsafe(32)})
 (O/'B-owner-setup.json').write_text(call(base+['owner-setup']+args+['--cli-bin','/opt/oap-journey-bundle/bin/oap','--out',str(D/'creds/owner.json')],owner))
 with open('/etc/hosts','a') as f:f.write('\n127.0.0.1 cli.journey.test rest.journey.test mcp.journey.test\n')
 (O/'phase-ab-finished-at.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
 os.execv(sys.executable,[sys.executable,'/opt/local-runner.py'])
except Exception as e:
 (O/'local-setup-finding.json').write_text(json.dumps({'step':'local Phase A/B','message':str(e)}));raise
