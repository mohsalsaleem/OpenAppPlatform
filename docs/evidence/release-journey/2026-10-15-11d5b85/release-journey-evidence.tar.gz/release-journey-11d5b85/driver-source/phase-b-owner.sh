set -eu
export PATH=/opt/oap-prerequisites/python/bin:$PATH
cd /opt/openappplatform-source
printf "B-start %s\n" "$(date -u +%FT%TZ)" >> /opt/oap-journey-evidence/timings.txt
python3 scripts/install.py owner-setup --json --directory /opt/oap-journey --cli-bin /opt/oap-journey-bundle/bin/oap --out /opt/oap-journey/creds/owner.json < /opt/oap-standalone/private-owner.json > /opt/oap-journey-evidence/B-owner-setup.json
date -u +%FT%TZ > /opt/oap-journey-evidence/phase-ab-finished-at.txt

printf "B-end %s\n" "$(date -u +%FT%TZ)" >> /opt/oap-journey-evidence/timings.txt
