import os,json,time,subprocess,traceback,urllib.parse,signal
from pathlib import Path
R=Path('/Users/samsal/saleem/incubator/products/openappplatform'); J=R/'tests/vps/release-journey'; D=Path('/opt/oap-journey'); O=R/'.local/journey-11d5b85/evidence'; URL='http://127.0.0.1:8878'; BASE='nishashipping.com'; SHA=json.loads((R/'.local/journey-11d5b85/bundle/manifest.json').read_text())['commit']
os.chdir(R); os.umask(0o077)
images=json.loads((O/'images.json').read_text()); results={}; contexts={};remote_index=0
def save(p,x):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2)+'\n'); return p
def server_exec(command,timeout=700):
 import shlex
 global remote_index
 if (Path(__file__).parent/'HOST_STOP.json').exists():raise Finding('Host health stop; no further operations admitted by test driver')
 remote_index+=1
 folder='/opt/oap-journey-evidence/transport'
 stdout=folder+('/%04d.stdout'%remote_index);stderr=folder+('/%04d.stderr'%remote_index)
 code="import json,pathlib,sys;print(json.dumps({'returncode':int(sys.argv[1]),'stdout':pathlib.Path(sys.argv[2]).read_text(),'stderr':pathlib.Path(sys.argv[3]).read_text()}))"
 script="export PATH=/opt/oap-prerequisites/python/bin:$PATH\nmkdir -p "+folder+"\n"+command+" > "+stdout+" 2> "+stderr+"\nrc=$?\necho BEGIN_JOURNEY\npython3 -c "+shlex.quote(code)+' "$rc" '+shlex.quote(stdout)+' '+shlex.quote(stderr)+"\necho END_JOURNEY\n"
 path=Path('/Users/samsal/saleem/incubator/products/openappplatform/.local/journey-11d5b85')/('ssh-%04d.sh'%remote_index);path.write_text(script)
 p=subprocess.run(['expect',str(path.parent/'ssh.exp'),str(path)],text=True,capture_output=True,timeout=timeout+40)
 if p.returncode:
  (Path(__file__).parent/'HOST_STOP.json').write_text(json.dumps({'reason':'ssh_lost','outcome':'uncertain'}));raise Finding('SSH lost; remote outcome uncertain: '+p.stdout[-200:])
 try:x=json.loads(p.stdout)
 except ValueError:
  (Path(__file__).parent/'HOST_STOP.json').write_text(json.dumps({'reason':'ssh_receipt_missing','outcome':'uncertain'}));raise Finding('Missing SSH command receipt; remote outcome uncertain: '+p.stdout[-200:])
 return x['returncode'],x['stdout'],x['stderr']

def shell(cmd,timeout=700):
 import shlex,base64
 if cmd[0]=='curl' and any(str(v).startswith('https://') for v in cmd) or cmd[0]=='python3' and any(str(v).endswith('/probe.py') for v in cmd):
  p=subprocess.run(cmd,text=True,capture_output=True,timeout=timeout);return p.returncode,p.stdout,p.stderr
 replacements={str(O):'/opt/oap-journey-evidence',str(R):'/opt/openappplatform-source'}
 def remote(v):
  v=str(v)
  for a,b in replacements.items():v=v.replace(a,b)
  return v
 prefix='cd '+('/opt/oap-journey' if cmd[:2]==['docker','compose'] else '/opt/openappplatform-source')+'\n'
 for v in cmd:
  candidate=str(v).lstrip('@')
  p=Path(candidate)
  if candidate.startswith(str(O)) and p.is_file():
   target=remote(candidate);encoded=base64.b64encode(p.read_bytes()).decode()
   prefix+='mkdir -p '+shlex.quote(str(Path(target).parent))+'\nprintf %s '+shlex.quote(encoded)+' | base64 -d > '+shlex.quote(target)+'\n'
 return server_exec(prefix+shlex.join([remote(v) for v in cmd]),timeout)

def sync_evidence(phase):
 import shlex
 server_exec('printf %s '+shlex.quote(phase+' ')+' >> /opt/oap-journey-evidence/timings.txt; date -u +%FT%TZ >> /opt/oap-journey-evidence/timings.txt')
 folder=Path(__file__).parent/'evidence'/'snapshots'/phase;folder.parent.mkdir(parents=True,exist_ok=True)
 p=subprocess.run(['expect',str(Path(__file__).parent/'scp.exp'),'vultr_oap:/opt/oap-journey-evidence',str(folder)],capture_output=True,text=True,timeout=180)
 if p.returncode:raise Finding('Evidence copy failed after '+phase)

def owner(name,cmd,body=None,flags=[]):
 c=['/opt/oap-journey-bundle/bin/oap','--url',URL,'--credential-file',str(D/'creds/owner.json')]+flags
 if body is not None:c+=['--file',str(save(O/(name+'-request.json'),body))]
 code,out,err=shell(c+[cmd]); x=json.loads(out);save(O/(name+'.json'),{'exitCode':code,'response':x,'stderr':err});
 if not x.get('ok'):raise RuntimeError('Owner step failed: '+name)
 return x['data']
class Finding(Exception):pass
class Run:
 def __init__(self,name):
  self.name=name;self.out=O/name;self.out.mkdir(exist_ok=True);self.cred=D/f'creds/onboard-{name}.json';self.app=None;self.v=None;self.n=0;self.current='B';self.ops=[];self.probes=[];self.start=time.time();self.receipt={'schemaVersion':1,'run':name,'status':'failed','commit':SHA,'oapImage':images['OAP_IMAGE'],'tls':'letsencrypt','steps':{},'observations':{},'operations':self.ops,'findings':[]};self.header()
 def header(self):
  if self.name=='rest':
   import shlex
   code="import json,pathlib; p=pathlib.Path("+repr(str(D/f'creds/{self.name}.hdr'))+");p.write_text('Authorization: Bearer '+json.load(open("+repr(str(self.cred))+"))['token']+chr(10));p.chmod(0o600)"
   server_exec('python3 -c '+shlex.quote(code))
 def check(self,condition,message):
  if not condition:raise Finding(message)
 def call(self,label,action,body=None,app=None,plan=None,op=None,key=None,allow=False):
  self.n+=1;stem=f'{self.n:03d}-{label}'; target=app or self.app
  if body is not None:bf=save(self.out/(stem+'-request.json'),body)
  if self.name=='cli':
   names={'validate':'validate-spec','plan':'action-plan','execute':'execute-action','getplan':'get-action-plan','instances':'verify','incident':'incident','wait':'wait','rollbackplan':'rollback-plan','rollback':'rollback','cap':'capabilities'}
   c=['/opt/oap-journey-bundle/bin/oap','--url',URL,'--credential-file',str(self.cred)]
   if target:c+=['--app',target]
   if plan:c+=['--plan',plan]
   if op:c+=['--operation',op,'--timeout','10m']
   if key:c+=['--key',key]
   if action=='incident':c+=['--component',body['component'],'--ordinal',str(body.get('ordinal',1))];body=None
   if body is not None:c+=['--file',str(bf)]
   code,out,err=shell(c+[names[action]]);x=json.loads(out);data=x.get('data');ok=x.get('ok',False);meta={'exitCode':code,'response':x,'stderr':err}
  elif self.name=='rest':
   path='/api/v1/applications/'+str(target)
   method,endpoint={'validate':('POST','/api/v1/specifications/validate'),'plan':('POST','/api/v1/action-plans'),'execute':('POST','/api/v1/action-plans/'+str(plan)+'/execute'),'getplan':('GET','/api/v1/action-plans/'+str(plan)),'instances':('GET',path+'/instances'),'incident':('GET',path+'/incident?'+urllib.parse.urlencode(body or {})),'wait':('GET','/api/v1/deployments/'+str(op)),'rollbackplan':('GET',path+'/rollback-plan?'+urllib.parse.urlencode(body or {})),'rollback':('POST',path+'/rollbacks'),'targetcap':('GET','/api/v1/targets/docker-local/capabilities'),'cap':('GET',path+'/capabilities')}[action]
   c=['curl','-sS','--max-time','40','-H','@'+str(D/f'creds/{self.name}.hdr'),'-H','Content-Type: application/json','-X',method]
   if key:c+=['-H','Idempotency-Key: '+key]
   if method=='POST':c+=['--data','@'+str(bf)]
   c+=['-w','\n%{http_code}',URL+endpoint];code,out,err=shell(c);raw,status=out.rsplit('\n',1);x=json.loads(raw);ok=code==0 and 200<=int(status)<300;data=x;meta={'httpStatus':int(status),'response':x,'stderr':err}
  else:
   tool={'validate':'validate_specification','plan':'create_action_plan','execute':'execute_action_plan','getplan':'get_action_plan','instances':'inspect_instances','incident':'get_incident_context','wait':'wait_operation','rollbackplan':'plan_rollback','rollback':'execute_rollback','cap':'inspect_capabilities','list':'list'}[action]
   args=body or {}
   if action=='plan':args={'request':body}
   elif action in ['execute','getplan']:args={'planId':plan}
   elif action=='wait':args={'deploymentId':op,'timeoutSeconds':600}
   elif action in ['instances','incident','rollbackplan','rollback','cap']:args={'applicationId':target,**args}
   if action=='rollback':args['idempotencyKey']=key
   af=save(self.out/(stem+'-mcp-args.json'),args)
   c=['python3','-I',str(J/'mcp_call.py'),'--bin','/opt/oap-journey-bundle/bin/oap-mcp','--url',URL,'--credential-file',str(self.cred)]
   c+=['list'] if action=='list' else ['call',tool,'--args',str(af)]
   code,out,err=shell(c);x=json.loads(out);data=x.get('data');ok=x.get('ok',False);meta={'exitCode':code,'response':x,'stderr':err}
  save(self.out/(stem+'-response.json'),meta);self.lastfile=str(self.out/(stem+'-response.json'))
  if not ok and not allow:raise Finding(f'{label}: interface request rejected; see {self.lastfile}')
  return data if ok else {'_error':meta,'_data':data}
 def plan(self,label,body):
  p=self.call(label+'-plan','plan',body);self.check(bool(p.get('id')),label+': missing plan ID')
  if p.get('requiresReview'):owner(self.name+'-'+label+'-owner-approval','approve-action',{'planHash':p['planHash']},['--plan',p['id']])
  e=self.call(label+'-execute','execute',{},plan=p['id']);return p,e['result']
 def wait(self,label,op):
  self.ops.append(op)
  if self.name=='rest':
   until=time.monotonic()+600
   while True:
    x=self.call(label+'-poll','wait',op=op)
    if x['state'] in ['succeeded','failed','attention','cancelled','abandoned']:return x
    if time.monotonic()>until:raise Finding(label+': client wait timed out')
    time.sleep(2)
  x=self.call(label+'-wait','wait',op=op,allow=True)
  if '_error' in x:
   data=x.get('_data')
   if isinstance(data,dict) and 'state' in data:return data
   # Read the same operation through the same interface: CLI operation, MCP wait.
   if self.name=='cli':
    c=['/opt/oap-journey-bundle/bin/oap','--url',URL,'--credential-file',str(self.cred),'--operation',op,'operation'];code,out,err=shell(c);y=json.loads(out);save(self.out/(label+'-operation.json'),y);return y.get('data',{})
   af=save(self.out/(label+'-get-operation-args.json'),{'deploymentId':op})
   code,out,err=shell(['python3','-I',str(J/'mcp_call.py'),'--bin','/opt/oap-journey-bundle/bin/oap-mcp','--url',URL,'--credential-file',str(self.cred),'call','get_deployment','--args',str(af)])
   y=json.loads(out);save(self.out/(label+'-get-operation.json'),y)
   if y.get('ok'):return y['data']
   raise Finding(label+': wait returned no operation evidence')
  return x
 def configure(self,label,spec):
  p,e=self.plan(label,{'action':'configure','applicationId':self.app,'expectedVersion':self.v,'specification':spec});self.v=e['definitionVersion']
 def deploy(self,label,extra={}):
  p,e=self.plan(label,{'action':'deploy','applicationId':self.app,'expectedVersion':self.v,**extra});return p,e,self.wait(label,e['operationId'])
 def stop_probe(self,p):
  self.check(p.poll() is None,'Traffic probe expired before operation completion')
  p.send_signal(signal.SIGTERM);p.wait(timeout=15);self.check(p.returncode==0,'Traffic probe did not produce its summary')
 def probe(self,label,duration,instances=None,background=False):
  cmd=['python3','-I',str(J/'probe.py'),'--url',f'https://{self.name}.{BASE}/api','--duration',str(duration),'--concurrency','2','--out',str(self.out/(label+'.json'))]
  if instances:cmd+=['--expect-instances',str(instances)]
  if background:
   f=open(self.out/(label+'-stdout.json'),'w');p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT);self.probes.append((p,f));return p
  code,out,err=shell(cmd,timeout=duration+30);x=json.loads(out);self.check(code==0,label+': backend count differed');return x
 def traffic(self,label,path):
  code,out,err=shell(['curl','-sS','--max-time','20',f'https://{self.name}.{BASE}{path}']);save(self.out/(label+'.json'),{'exitCode':code,'body':out,'stderr':err});self.check(code==0,label+': public HTTPS failed');return json.loads(out)
 def health(self,label,empty=False):
  x=self.call(label,'instances',allow=empty)
  save(self.out/(label+'-normalized.json'),x)
  if empty:
   items=(x.get('_data') if '_error' in x else x);items=items.get('instances',[]) if isinstance(items,dict) else (items or []);self.check(all(not i.get('status','').startswith('running') for i in items),label+': containers running after save only')
  else:
   self.check('_error' not in x,label+': health verification failed');items=x.get('instances',[]) if isinstance(x,dict) else x;self.check(bool(items) and all(i.get('status')=='completed:0' if i.get('kind')=='job' else i.get('status')=='running:healthy' for i in items if not i.get('retired')),label+': instances are not all healthy')
  return x
 def perform(self):
  self.current='C1'
  if self.name=='mcp':self.check(len(self.call('tools','list'))==19,'MCP expected 19 tools');self.receipt['steps']['discover']=True
  if self.name=='rest':self.call('S1-target-capabilities','targetcap');self.receipt['steps']['discover']=True
  text=(J/'application.template.json').read_text()
  for k,v in {'__JOB_IMAGE__':images['JOB'],'__API_V1_IMAGE__':images['API1'],'__WEB_IMAGE__':images['WEB'],'__NOTES_IMAGE__':images['NOTES'],'__WORKER_IMAGE__':images['WORKER'],'__DOMAIN__':self.name+'.'+BASE}.items():text=text.replace(k,v)
  spec=json.loads(text.replace('"release-journey"','"release-journey-'+self.name+'"'));save(self.out/'spec-initial.json',spec)
  self.call('C1-validate','validate',{'specification':spec});self.receipt['steps']['validate']=True
  self.current='C2';p,e=self.plan('C2-create',{'action':'create','specification':spec});self.app=e['applicationId'];self.v=e['definitionVersion'];self.health('C2-instances',empty=True);self.receipt['steps']['createWithoutDeploy']=True
  self.current='C3';owner(self.name+'-C3-app-grant','app-grant',{'name':f'Journey app agent ({self.name})','scope':'operate','applicationId':self.app,'actions':['configure','deploy','scale-down','recover','rollback']},['--out',str(D/f'creds/app-{self.name}.json')]);self.cred=D/f'creds/app-{self.name}.json';self.header();self.receipt['steps']['appGrant']=True
  self.current='C4';p,e,op=self.deploy('C4');self.check(op.get('state')=='succeeded','C4 operation did not succeed');steps=op.get('steps',[]);self.check(steps and steps[0].get('component')=='migrate' and steps[0].get('exitCode')==0,'C4 first step was not successful migration');self.receipt['steps']['deployWithMigration']=True;self.health('C4-health');re=self.call('C4-replay','execute',{},plan=p['id']);self.check(re['result']['operationId']==e['operationId'],'C4 replay created different operation');self.receipt['steps']['planReplaySameOperation']=True
  self.traffic('C4-web','/');api=self.traffic('C4-api','/api');notes=self.traffic('C4-notes','/notes');self.check(api.get('version')=='v1' and notes.get('boots')==1,'C4 app responses differ');self.receipt['steps']['publicHttpsTrusted']=True
  if self.name != 'cli':
   self.current='S5';inc=self.call('S5-incident','incident',{'component':'api','ordinal':1});self.check(inc.get('state')=='observed_healthy' and inc.get('applicationBehaviorVerified') is False and bool(inc.get('generatedAt')) and bool(inc.get('validUntil')),'S5 incident or freshness differs');self.receipt['steps']['incidentRead']=True
   self.current='S6';denied=self.call('S6-denied','cap',app=contexts['cli'].app,allow=True);self.check('_error' in denied,'S6 cross-app request was not denied');self.receipt['steps']['crossAppDenied']=True;self.receipt['status']='passed';return
  sync_evidence('before-D1')
  self.current='D1';next(c for c in spec['spec']['components'] if c['name']=='api')['instances']=3;pr=self.probe('D1-probe',240,background=True);self.configure('D1-configure',spec);p,e,op=self.deploy('D1-deploy');self.check(op.get('state')=='succeeded','D1 did not succeed');d1=e['operationId'];self.stop_probe(pr);post=self.probe('D1-after',20,3);self.check(set(post['versions'])=={'v1'},'D1 wrong versions');self.receipt['steps'].update(scaleUpTo3=True,trafficOnAll3=True);self.receipt['observations']['scaleUpFailures']=json.loads((self.out/'D1-probe.json').read_text())['failures']
  sync_evidence('before-E1')
  self.current='E1';job=next(c for c in spec['spec']['components'] if c['name']=='migrate');job['env']['JOB_EXIT_CODE']='7';self.configure('E1-configure',spec);p,e,op=self.deploy('E1-deploy');self.check(op.get('state')=='failed','E1 expected failed');ss=op.get('steps',[]);self.check(any(s.get('component')=='migrate' and s.get('exitCode')==7 for s in ss) and all(not s.get('remoteDeploymentId') for s in ss if s.get('component')=='api'),'E1 job did not block API');self.receipt['steps']['failingMigrationBlocksRollout']=True
  inc=self.call('E1-incident','incident',{'component':'migrate','ordinal':1});self.check(inc.get('state')=='issue' and inc.get('applicationBehaviorVerified') is False,'E1 incident differs');self.receipt['steps']['incidentIdentifiesJob']=True;post=self.probe('E1-after',20,3);self.check(set(post['versions'])=={'v1'},'E1 altered serving version');job['env']['JOB_EXIT_CODE']='0';self.configure('E1-restore',spec)
  self.current='E2';pr=self.probe('E2-probe',180,background=True);p,e,op=self.deploy('E2-broken',{'components':['api'],'images':{'api':images['APIBAD']}});self.check(op.get('state')=='failed','E2 expected failed, got '+str(op.get('state')));self.receipt['steps']['brokenReleaseNotCompleted']=True;inc=self.call('E2-incident','incident',{'component':'api','ordinal':1});self.check(inc.get('state')=='issue' and images['APIBAD'] in json.dumps(inc),'E2 incident missing image comparison');self.receipt['steps']['incidentIdentifiesApi']=True;self.stop_probe(pr);self.receipt['observations']['brokenReleaseApiFailures']=json.loads((self.out/'E2-probe.json').read_text())['failures']
  self.current='E3';p,e,op=self.deploy('E3-correct',{'components':['api','notes'],'images':{'api':images['API2'],'notes':images['NOTES2']}});self.check(op.get('state')=='succeeded','E3 did not succeed');self.health('E3-health');post=self.probe('E3-after',20,3);self.check(set(post['versions'])=={'v2'},'E3 wrong version');self.receipt['steps']['correctedToV2']=True;notes_e3=self.traffic('E3-notes','/notes');self.check(notes_e3.get('boots')==2,'E3 volume was not retained during image replacement')
  sync_evidence('before-F')
  self.current='F';rp=self.call('F-plan','rollbackplan',{'releaseId':d1,'expectedVersion':self.v});self.check('migrate' in rp.get('skippedJobs',[]) and len(rp.get('instances',[]))==6,'F rollback snapshot incomplete');body={'releaseId':d1,'expectedVersion':self.v,'planHash':rp['planHash'],'acknowledgeDataCompatibility':True};rb=self.call('F-execute','rollback',body,key=f'journey-{self.name}-rollback-1');oid=rb.get('id') or rb.get('operationId');self.check(bool(oid),'F missing operation ID');op=self.wait('F',oid);self.check(op.get('state')=='succeeded','F rollback did not succeed');again=self.call('F-replay','rollback',body,key=f'journey-{self.name}-rollback-1');self.check((again.get('id') or again.get('operationId'))==oid,'F replay differs');self.health('F-health');post=self.probe('F-after',20,3);self.check(set(post['versions'])=={'v1'},'F wrong version');self.check(all(s.get('component')!='migrate' for s in op.get('steps',[])),'F reran migration');notes2=self.traffic('F-notes','/notes');self.check(notes2.get('boots',0)>notes_e3['boots'],'F volume not retained');self.receipt['steps'].update(appWideRollback=True,rollbackSkippedMigration=True,rollbackReplay=True,volumeDataRetained=True)
  sync_evidence('before-H')
  self.current='H';next(c for c in spec['spec']['components'] if c['name']=='api')['instances']=1;pr=self.probe('H-probe',120,background=True);p,e=self.plan('H-scale-down',{'action':'scale-down','applicationId':self.app,'expectedVersion':self.v,'specification':spec});self.v=e['definitionVersion'];op=self.wait('H',e['operationId']);self.check(op.get('state')=='succeeded','H did not succeed');self.stop_probe(pr);post=json.loads((self.out/'H-probe.json').read_text());self.check(post['failures']==0,'H probe failures');self.health('H-health');self.probe('H-after',20,1);self.receipt['steps'].update(scaleDownTo1=True,scaleDownFailures=0);self.receipt['status']='passed'
 def finish(self):
  for p,f in self.probes:
   if p.poll() is None:p.send_signal(signal.SIGTERM)
   p.wait(timeout=15);f.close()
  self.receipt['applicationId']=self.app;self.receipt['durationSeconds']=round(time.time()-self.start,2);self.receipt['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save(self.out/(f'release-journey-{self.name}.json' if self.name=='cli' else f'smoke-{self.name}.json'),self.receipt);print(json.dumps({'run':self.name,'status':self.receipt['status'],'step':self.current,'seconds':self.receipt['durationSeconds']}),flush=True)
for name in ['cli','rest','mcp']:
 owner('B-grant-'+name,'grant',{'name':f'Journey agent ({name})','targetId':'docker-local','environment':'production','maxApplications':1,'actions':['configure','deploy','recover','rollback']},['--out',str(D/f'creds/onboard-{name}.json')])
sync_evidence('B-grants')
for name in ['cli','rest','mcp']:
 r=Run(name);contexts[name]=r
 try:r.perform()
 except Exception as e:
  r.receipt['findings'].append({'step':r.current,'message':str(e),'evidence':getattr(r,'lastfile',''),'trace':traceback.format_exc()});
  if r.app:
   for label,action,body in [('failure-instances','instances',None),('failure-incident','incident',{'component':'api','ordinal':1})]:
    try:r.call(label,action,body,allow=True)
    except Exception:pass
 finally:r.finish();results[name]=r.receipt['status'];sync_evidence(name)
save(O/'parity.json',{'schemaVersion':1,'commit':SHA,'runs':results,'status':'failed','coexistence':None,'isolation':None,'controllerOutageFailures':None,'pauseRevoke':None,'gaps':[{'interface':'mcp','step':'verify','used':'inspect_instances','note':'no verify tool'}],'differences':[],'note':'Phase X pending'})
parity=json.loads((O/'parity.json').read_text());parity['findings']=[]
def xfinding(step,message,evidence):parity['findings'].append({'step':step,'message':message,'evidence':str(evidence)})
# Phase X observes all apps even if individual runs stopped; missing prerequisites are recorded.
for r in contexts.values():
 try:r.traffic('X1-public-api','/api')
 except Exception as e:xfinding('X1',str(e),r.lastfile if hasattr(r,'lastfile') else r.out)
import ssl,socket
for name in contexts:
 domain=name+'.'+BASE
 try:
  with socket.create_connection((domain,443),timeout=20) as conn:
   with ssl.create_default_context().wrap_socket(conn,server_hostname=domain) as tls:
    save(O/('X1-tls-'+name+'.json'),{'hostname':domain,'systemTrustVerified':True,'protocol':tls.version(),'certificate':tls.getpeercert()})
 except Exception as e:xfinding('X1','Public TLS verification failed: '+str(e),O/('X1-tls-'+name+'.json'))
code,out,err=shell(['curl','-sS','--max-time','10','-H','Host: unknown.invalid','-w','\n%{http_code}','https://cli.nishashipping.com/']);save(O/'X1-unknown-host.json',{'exitCode':code,'response':out,'stderr':err});unknown=out.rsplit('\n',1)[-1];parity['coexistence']=not any(f['step']=='X1' for f in parity['findings']) and unknown in ['404','421','403']
code,before,err=shell(['docker','ps','--format','{{.ID}} {{.Names}}']);(O/'X3-before.txt').write_text(before)
code,out,err=shell(['docker','compose','--project-directory',str(D),'stop','platform']);save(O/'X3-stop.json',{'exitCode':code,'stdout':out,'stderr':err})
probes=[]
for r in contexts.values():probes.append((r,r.probe('X3-probe',60,background=True)))
for r,p in probes:p.wait()
code,out,err=shell(['docker','compose','--project-directory',str(D),'up','-d','--wait','platform']);save(O/'X3-start.json',{'exitCode':code,'stdout':out,'stderr':err})
code,out,err=shell(['python3','scripts/install.py','check','--json','--directory',str(D)]);save(O/'X3-check.json',{'exitCode':code,'response':json.loads(out),'stderr':err})
code,after,err=shell(['docker','ps','--format','{{.ID}} {{.Names}}']);(O/'X3-after.txt').write_text(after)
fails=sum(json.loads((r.out/'X3-probe.json').read_text())['failures'] for r in contexts.values());parity['controllerOutageFailures']=fails
stable=lambda s:set(l for l in s.splitlines() if '-platform-' not in l)
parity['workloadAndProxyIdsUnchanged']=stable(before)==stable(after)
for r in contexts.values():
 if r.app:
  try:r.call('X3-after-read','cap')
  except Exception as e:xfinding('X3',str(e),r.lastfile)
code,out,err=shell(['docker','compose','--project-directory',str(D),'ps','-q']);ids=out.split();code,out,err=shell(['docker','stats','--no-stream','--format','{{json .}}']+ids);(O/'X5-stats.jsonl').write_text(out);parity['footprint']='X5-stats.jsonl'
code,out,err=shell(['docker','system','df']);(O/'X5-disk.txt').write_text(out);parity['disk']='X5-disk.txt'
code,out,err=shell(['docker','ps','-a','--format','{{.Names}}']);count=sum('migrate' in l for l in out.splitlines());save(O/'X5-retained-jobs.json',{'count':count})
parity['differences']=[{'interface':n,'findings':r.receipt['findings']} for n,r in contexts.items() if r.receipt['findings']]
parity['status']='passed' if all(s=='passed' for s in results.values()) and parity['coexistence'] and fails==0 and parity['workloadAndProxyIdsUnchanged'] and not parity['findings'] else 'failed'
parity.pop('note',None);parity['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save(O/'parity.json',parity)
start=(O/'started-at.txt').read_text().strip();from datetime import datetime,timezone
save(O/'timing.json',{'startedAt':start,'finishedAt':parity['finishedAt'],'totalSeconds':round(time.time()-datetime.fromisoformat(start.replace('Z','+00:00')).timestamp(),2),'phaseABFinishedAt':(O/'phase-ab-finished-at.txt').read_text().strip(),'runs':{n:r.receipt['durationSeconds'] for n,r in contexts.items()}})
print(json.dumps({'phase':'X','status':parity['status']}),flush=True)

code,out,err=server_exec('kill "$(cat /opt/oap-journey-evidence/monitor.pid)"\npython3 -I /opt/openappplatform-source/tests/vps/release-journey/monitor.py summary --file /opt/oap-journey-evidence/monitor.jsonl --kernel-log')
host=json.loads(out);save(O/'X3-host.json',host);(Path(__file__).parent/'HEARTBEAT_DONE').touch()
health_lines=(Path(__file__).parent/'evidence/ssh-health.jsonl').read_text().splitlines()
host['sshLost']=(Path(__file__).parent/'HOST_STOP.json').exists()
parity['status']='passed' if parity['status']=='passed' and host.get('oomKills')==0 and host.get('minMemAvailableMiB',0)>100 and host.get('maxSwapUsedMiB',-1)==0 and host.get('memTotalMiB',99999)<=1024 and not host['sshLost'] else 'failed'
save(O/'v0.1-journey.json',{'schemaVersion':1,'commit':SHA,'environment':'vps','tls':'letsencrypt','vpsExecuted':True,'status':parity['status'],'cli':results['cli'],'smoke':{n:results[n] for n in ['rest','mcp']},'coexistence':parity['coexistence'],'controllerOutageFailures':fails,'workloadAndProxyIdsUnchanged':parity['workloadAndProxyIdsUnchanged'],'findings':parity['findings']+[f for r in contexts.values() for f in r.receipt['findings']],'host':host,'timings':json.loads((O/'timing.json').read_text())})

if parity['status']!='passed':
 code,out,err=shell(['docker','compose','--project-directory',str(D),'logs','--no-color','ingress']);(O/'failure-ingress.log').write_text(out+err)
 code,out,err=shell(['docker','ps','-a','--format','{{json .}}']);(O/'failure-containers.jsonl').write_text(out)

sync_evidence('final');(Path(__file__).parent/'HEARTBEAT_DONE').touch()
