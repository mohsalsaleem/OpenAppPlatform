set -eu
OUT=/opt/oap-journey-evidence/H-diagnostics
mkdir -p "$OUT"
cd /opt/oap-journey
ID=$(docker compose ps -q ingress)
docker logs --timestamps --since 2026-10-15T15:16:14Z --until 2026-10-15T15:17:08Z "$ID" > "$OUT/caddy-window.log" 2>&1
for NAME in oap-3d902c7f0296-api-1 oap-3d902c7f0296-api-2 oap-3d902c7f0296-api-3; do
 docker inspect --format '{"name":{{json .Name}},"id":{{json .Id}},"status":{{json .State.Status}},"oomKilled":{{json .State.OOMKilled}},"exitCode":{{json .State.ExitCode}},"restartCount":{{json .RestartCount}},"startedAt":{{json .State.StartedAt}},"finishedAt":{{json .State.FinishedAt}}}' "$NAME"
done > "$OUT/api-container-state.jsonl"
docker events --since 2026-10-15T15:16:14Z --until 2026-10-15T15:17:08Z --format '{{json .}}' > "$OUT/docker-events.jsonl"
printf 'Read-only scale-down diagnostics collected\n'
